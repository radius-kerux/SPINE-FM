<?php 

class install
{
	public function __construct()
	{
		$zip	=	new ZipArchive();
		$inst	=	$zip->open('install.zip');
		
		if ($inst === TRUE)
		{
			$zip->extractTo('/');
			$zip->close();
		}
		
	}
	
}