<?php
class learnController extends Spine_SuperController
{
	public function indexAction()
	{
		echo "<h2>Did you just requested for Learn More? =)</h2>";
	}
}