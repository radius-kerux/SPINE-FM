<?php
class learnController extends Spine_SuperController
{
	public function indexAction()
	{
		echo "<h2>Sample learn more page.</h2>";
	}
}