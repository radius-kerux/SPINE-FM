<?php

/**
*
*
*
*/

class override extends Spine_OverrideAbstract
{
	protected $overrides_array	=	array(
		'sitemap.xml'	=>	array(
			'call_back'	=>	'displayXml'
		)
	);

	public function siteInfo($parameters = array())
	{
		echo 'Hi '.$parameters['name'].'!'.
			'<br/>'.$parameters['message'];
	}
}