<?php

define('SITE', 'website');

//------------------------------------------------------------------------------------

define ('DATABASE_NAME', 'spine_db');
define ('DATABASE_HOSTNAME', 'localhost');
define ('DATABASE_USERNAME', 'root');
define ('DATABASE_PASSWORD', '');

//------------------------------------------------------------------------------------

define('MAIN_CONTROLLER', 'main');
define('MAIN_METHOD', 'main');
define('END_METHOD', 'end');

define('DEFAULT_CONTROLLER', 'index');
define('DEFAULT_METHOD', 'index');

//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
//This will be used by Auths
define('USE_SESSION', false);
define('HASH_KEY', 'hashkeySpine1234567890######');

