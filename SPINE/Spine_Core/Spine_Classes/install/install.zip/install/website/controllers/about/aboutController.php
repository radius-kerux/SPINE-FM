<?php
class aboutController extends Spine_SuperController
{
	public function main()
	{
	}
	
	public function indexAction()
	{
	}
}