<?php 
include_once '/plugins/php.jquery/library/jQuery.php';
include_once '/plugins/global_functions/global_functions.php';

?>