<?php

/**
*
*
*
*/

class globalOverride extends Spine_OverrideAbstract
{
	protected $overrides_array	=	array(
		'_info'			=>	array(
			'call_back'	=>	'siteInfo',
			'parameters'=>	array(
				'name'		=>	'Your Name',
				'message'	=>	'Your message'
			),
			'exit'		=>	TRUE	
		)
	);

// -------------------------------------------------------------------------------------------------------------------	
	
	public function siteInfo()
	{
		echo 'Access Forbidden';
	}
	
// -------------------------------------------------------------------------------------------------------------------
}